export default {
	"HWGraphQL": {
		"footer": {
			"copyrightText": "",
			"sidebarOne": "<div class=\"widget widget_text\"><div class=\"widget-content\"><h2 class=\"widget-title subheading heading-size-3\">Widget One</h2>\t\t\t<div class=\"textwidget\"><p><em>Lorem ipsum</em>, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero&#8217;s De Finibus Bonorum et Malorum for use in a type specimen book.</p>\n</div>\n\t\t</div></div>",
			"sidebarTwo": "<div class=\"widget widget_text\"><div class=\"widget-content\"><h2 class=\"widget-title subheading heading-size-3\">Widget Two</h2>\t\t\t<div class=\"textwidget\"><p><em>Lorem ipsum</em>, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero&#8217;s De Finibus Bonorum et Malorum for use in a type specimen book.</p>\n</div>\n\t\t</div></div>",
			"socialLinks": []
		},
		"footerMenuItems": {
			"edges": [
				{
					"node": {
						"id": "bmF2X21lbnVfaXRlbTozODk=",
						"menuItemId": 389,
						"label": "Special Journeys",
						"url": "https://codeytek.com/headless-cms/special-journey/",
						"childItems": {
							"edges": []
						}
					}
				},
				{
					"node": {
						"id": "bmF2X21lbnVfaXRlbTozOTA=",
						"menuItemId": 390,
						"label": "Memories",
						"url": "https://codeytek.com/headless-cms/memories/",
						"childItems": {
							"edges": []
						}
					}
				},
				{
					"node": {
						"id": "bmF2X21lbnVfaXRlbTozOTE=",
						"menuItemId": 391,
						"label": "About",
						"url": "https://codeytek.com/headless-cms/about/",
						"childItems": {
							"edges": []
						}
					}
				},
				{
					"node": {
						"id": "bmF2X21lbnVfaXRlbTozOTI=",
						"menuItemId": 392,
						"label": "Enquiry",
						"url": "https://codeytek.com/headless-cms/enquiry/",
						"childItems": {
							"edges": []
						}
					}
				},
				{
					"node": {
						"id": "bmF2X21lbnVfaXRlbTozOTg=",
						"menuItemId": 398,
						"label": "Blog",
						"url": "https://codeytek.com/headless-cms/blog/",
						"childItems": {
							"edges": []
						}
					}
				}
			]
		}
	}
}
